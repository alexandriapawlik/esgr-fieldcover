﻿March 21, 2021
Jason:  
Attached are a portion of the raw data for the sample plots I worked at the George Reserve.  Because each of these folders is pretty big it will take several transmissions as there are a total of 18 sets of data.  The explanation in this email will pertain to all of the data sets. 
 
--Each data set consists of measurements from a 30m x 30m (900m2) plot located on a north-facing or south-facing slope.  Each plot is broken into 3 rows of 3 100m2 subplots at the bottom, middle, and top of the 900m2 plot.
--Data for Trees and Dead trees/shrubs are dbh.
--Data for Shrub and Tree reproduction are density (number)/100m2 subplot.
--Data for the Field layer (tree and shrub reproduction and herbs) are centimeters of cover as determined by the arrangement of meter sticks shown in the attached picture.  Coverage was determined in each 100m2 subplot along the central 10m diagonal strip in the subplot.  The actual numbers in the table represent the centimeters/10meter diagonal strip in each 100m2 plot summed for the three 100m2 plots at the bottom, middle, and top slope positions.  (Hope that's clear!!)


Attached are the referenced picture (I'll put that on each email) together with data from 6 plots.  If you have problems with all this let me know or give me a call (919-465-9281).  Art.
  


--
130 Wee Loch Drive
Cary, NC 27511-3885
919-465-9281
awcooper1953@gmail.com




March 25, 2021
Attached are two files, one with basal area data for south-facing slopes and one for north-facing slopes.  The data are self explanatory.  I also have files with the raw data from the field layers of each plot but I doubt you will want those.  They are very long tables; the only thing they will add to what I have sent is presence of herbs that otherwise don't appear in the data.  I've also got some pictures--color and b/w--so let me know if you want them.  I did even own a camera in those days so the pictures I have are ones I was able to con someone else into taking.  Thus there are pictures of just a few of the plots--they do show what they looked like in 1957-58.  Art.  


--
130 Wee Loch Drive
Cary, NC 27511-3885
919-465-9281
awcooper1953@gmail.com